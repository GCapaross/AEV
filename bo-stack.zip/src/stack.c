int foo(int bar){
	return 42 * bar;
}

int main(){
	foo(3);
	return 0;
}
